
import React, { useState, useMemo } from 'react';
import type { StockItem, PendingSO } from '../types';

interface StockCheckModalProps {
  isOpen: boolean;
  onClose: () => void;
  stockStatements: StockItem[] | null;
  pendingSOs: PendingSO[] | null;
}

// Safety check: if str is undefined/null, return empty string to prevent crash
const normalize = (str: string | undefined | null) => {
    if (!str) return '';
    return str.toLowerCase().replace(/[^a-z0-9]/g, '');
};

interface ProcessedStockItem extends StockItem {
    immediateDemand: number;
    scheduledDemand: number;
    freeStock: number;
    shortage: number;
    orders: Array<PendingSO & { status: string, isDueImmediate: boolean }>;
}

export const StockCheckModal: React.FC<StockCheckModalProps> = ({ isOpen, onClose, stockStatements, pendingSOs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedRowIds, setExpandedRowIds] = useState<Set<number>>(new Set());

  // Helper to toggle row expansion
  const toggleRow = (id: number) => {
      setExpandedRowIds(prev => {
          const newSet = new Set(prev);
          if (newSet.has(id)) newSet.delete(id);
          else newSet.add(id);
          return newSet;
      });
  };

  const processedData = useMemo(() => {
      if (!stockStatements || !pendingSOs) return [];

      const lowerTerm = searchTerm.toLowerCase();
      // Filter first for performance
      const filteredStock = searchTerm 
        ? stockStatements.filter(s => s.description && s.description.toLowerCase().includes(lowerTerm))
        : stockStatements;

      const today = new Date();
      const dueLimit = new Date(today);
      dueLimit.setDate(today.getDate() + 30); // Today + 30 Days

      return filteredStock.map(item => {
          const stockDescNorm = normalize(item.description);
          
          // Find matching SOs
          const matchingSOs = pendingSOs.filter(so => {
              const itemNorm = normalize(so.itemName);
              const partNorm = normalize(so.partNo);
              
              // Ensure we don't match empty strings against empty strings
              if (!stockDescNorm) return false;

              return itemNorm.includes(stockDescNorm) || 
                     (partNorm && partNorm.includes(stockDescNorm)) ||
                     (itemNorm && stockDescNorm.includes(itemNorm)) ||
                     (partNorm && stockDescNorm.includes(partNorm));
          });

          // Sort by Due Date (FIFO)
          matchingSOs.sort((a, b) => new Date(a.dueOn).getTime() - new Date(b.dueOn).getTime());

          let availableStock = item.quantity;
          let immediateDemand = 0;
          let scheduledDemand = 0;

          const ordersWithStatus = matchingSOs.map(so => {
              const dueDate = new Date(so.dueOn);
              const isDueImmediate = dueDate <= dueLimit;
              let status = 'Scheduled';

              if (isDueImmediate) {
                  immediateDemand += so.balanceQty;
                  if (availableStock >= so.balanceQty) {
                      status = 'Allocated';
                      availableStock -= so.balanceQty;
                  } else if (availableStock > 0) {
                      status = 'Partial';
                      availableStock = 0;
                  } else {
                      status = 'No Stock';
                  }
              } else {
                  scheduledDemand += so.balanceQty;
              }

              return { ...so, status, isDueImmediate };
          });

          // Free stock logic: Physical - Immediate Demand (floored at 0)
          const freeStock = Math.max(0, item.quantity - immediateDemand);
          const shortage = Math.max(0, immediateDemand - item.quantity);

          return {
              ...item,
              immediateDemand,
              scheduledDemand,
              freeStock,
              shortage,
              orders: ordersWithStatus
          };
      });
  }, [searchTerm, stockStatements, pendingSOs]);

  const getStatusBadge = (status: string) => {
      switch (status) {
          case 'Allocated': return <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-green-100 text-green-800 border border-green-200">Allocated</span>;
          case 'Partial': return <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-yellow-100 text-yellow-800 border border-yellow-200">Partial</span>;
          case 'No Stock': return <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-800 border border-red-200">Backorder</span>;
          case 'Scheduled': return <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-600 border border-blue-100">Future</span>;
          default: return null;
      }
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-7xl h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b flex justify-between items-center bg-gray-50 rounded-t-lg">
            <div>
                <h2 className="text-xl font-bold text-gray-800">Check Stock Availability</h2>
                <p className="text-xs text-gray-500 mt-1">Consolidated view of Physical Stock vs Immediate & Scheduled Demand</p>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl font-bold">&times;</button>
        </div>

        {/* Search */}
        <div className="p-4 border-b bg-white">
            <div className="relative">
                <input 
                    type="text" 
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder="Search Product Description / Part No..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    autoFocus
                />
                <svg className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
            </div>
        </div>

        {/* Main Table Content */}
        <div className="flex-grow overflow-auto bg-gray-50/50">
            <table className="min-w-full divide-y divide-gray-200 border-b border-gray-200">
                <thead className="bg-gray-100 sticky top-0 z-10 shadow-sm">
                    <tr>
                        <th scope="col" className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider w-10"></th>
                        <th scope="col" className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Description</th>
                        <th scope="col" className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase tracking-wider w-32">Physical Stock</th>
                        <th scope="col" className="px-4 py-3 text-right text-xs font-bold text-orange-600 uppercase tracking-wider w-32">Immediate<br/><span className="text-[9px] text-orange-400">(&lt; 30 Days)</span></th>
                        <th scope="col" className="px-4 py-3 text-right text-xs font-bold text-blue-600 uppercase tracking-wider w-32">Scheduled<br/><span className="text-[9px] text-blue-400">(&gt; 30 Days)</span></th>
                        <th scope="col" className="px-4 py-3 text-right text-xs font-bold text-green-600 uppercase tracking-wider w-32">Free Stock</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                    {processedData.length > 0 ? (
                        processedData.map(item => {
                            const isExpanded = expandedRowIds.has(item.id);
                            return (
                                <React.Fragment key={item.id}>
                                    <tr 
                                        className={`hover:bg-indigo-50/50 transition-colors cursor-pointer ${isExpanded ? 'bg-indigo-50' : ''}`}
                                        onClick={() => toggleRow(item.id)}
                                    >
                                        <td className="px-4 py-3 text-center">
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); toggleRow(item.id); }}
                                                className="text-gray-400 hover:text-indigo-600 focus:outline-none"
                                            >
                                                <svg className={`w-5 h-5 transform transition-transform ${isExpanded ? 'rotate-90' : ''}`} fill="currentColor" viewBox="0 0 20 20">
                                                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                                                </svg>
                                            </button>
                                        </td>
                                        <td className="px-4 py-3 text-sm font-medium text-gray-900">
                                            {item.description}
                                            {item.orders.length > 0 && <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-[10px] bg-gray-100 text-gray-600">{item.orders.length} Order(s)</span>}
                                        </td>
                                        <td className="px-4 py-3 text-sm text-gray-900 text-right font-semibold bg-gray-50/30">{item.quantity}</td>
                                        <td className="px-4 py-3 text-sm text-orange-700 text-right font-bold bg-orange-50/20">{item.immediateDemand}</td>
                                        <td className="px-4 py-3 text-sm text-blue-700 text-right font-medium bg-blue-50/20">{item.scheduledDemand}</td>
                                        <td className={`px-4 py-3 text-sm text-right font-bold ${item.freeStock > 0 ? 'text-green-700 bg-green-50/20' : 'text-red-600 bg-red-50/20'}`}>
                                            {item.freeStock}
                                            {item.shortage > 0 && (
                                                <div 
                                                    className="text-[9px] text-red-500 font-normal" 
                                                    title={`Shortage of ${item.shortage} units to fulfill immediate demand`}
                                                >
                                                    Short: {item.shortage}
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                    {isExpanded && (
                                        <tr className="bg-indigo-50/30 shadow-inner">
                                            <td colSpan={6} className="px-4 py-4 sm:px-12">
                                                <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                                                    <div className="px-4 py-2 bg-gray-50 border-b border-gray-200 text-xs font-bold text-gray-700 uppercase">
                                                        Detailed Order Breakdown
                                                    </div>
                                                    {item.orders.length > 0 ? (
                                                        <table className="min-w-full divide-y divide-gray-100">
                                                            <thead className="bg-gray-50">
                                                                <tr>
                                                                    <th className="px-4 py-2 text-left text-[10px] font-bold text-gray-500 uppercase">Date</th>
                                                                    <th className="px-4 py-2 text-left text-[10px] font-bold text-gray-500 uppercase">Customer Name</th>
                                                                    <th className="px-4 py-2 text-left text-[10px] font-bold text-gray-500 uppercase">Order No</th>
                                                                    <th className="px-4 py-2 text-left text-[10px] font-bold text-gray-500 uppercase">Item Name</th>
                                                                    <th className="px-4 py-2 text-right text-[10px] font-bold text-gray-500 uppercase">Bal Qty</th>
                                                                    <th className="px-4 py-2 text-left text-[10px] font-bold text-gray-500 uppercase">Due Date</th>
                                                                    <th className="px-4 py-2 text-center text-[10px] font-bold text-gray-500 uppercase">Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody className="divide-y divide-gray-100">
                                                                {item.orders.map((so, idx) => (
                                                                    <tr key={idx} className={so.isDueImmediate ? '' : 'text-gray-400'}>
                                                                        <td className="px-4 py-2 text-xs whitespace-nowrap">{new Date(so.date).toLocaleDateString()}</td>
                                                                        <td className="px-4 py-2 text-xs font-medium">{so.partyName}</td>
                                                                        <td className="px-4 py-2 text-xs">{so.orderNo}</td>
                                                                        <td className="px-4 py-2 text-[10px] max-w-xs truncate" title={so.itemName}>{so.itemName}</td>
                                                                        <td className="px-4 py-2 text-xs text-right font-bold">{so.balanceQty}</td>
                                                                        <td className="px-4 py-2 text-xs font-medium">
                                                                            {new Date(so.dueOn).toLocaleDateString()}
                                                                            {!so.isDueImmediate && <span className="ml-1 text-[9px] text-blue-400">(Sched)</span>}
                                                                        </td>
                                                                        <td className="px-4 py-2 text-center">
                                                                            {getStatusBadge(so.status)}
                                                                        </td>
                                                                    </tr>
                                                                ))}
                                                            </tbody>
                                                        </table>
                                                    ) : (
                                                        <div className="p-4 text-center text-sm text-gray-500 italic">No pending orders found for this item description.</div>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                </React.Fragment>
                            );
                        })
                    ) : (
                        <tr>
                            <td colSpan={6} className="px-4 py-12 text-center text-gray-500">
                                {searchTerm ? 'No stock items match your search.' : 'Start typing to search stock items...'}
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>

        {/* Footer */}
        <div className="p-4 border-t bg-gray-50 rounded-b-lg flex justify-between items-center">
            <div className="text-xs text-gray-500">
                <span className="font-bold">Note:</span> Free Stock = Physical Stock - Immediate Demand. 
                <span className="ml-2 inline-flex w-3 h-3 bg-red-100 border border-red-200 rounded-sm align-middle"></span> Shortage Indicator
            </div>
            <button onClick={onClose} className="px-6 py-2 bg-slate-700 hover:bg-slate-800 text-white rounded-md font-semibold transition-colors text-sm">Close</button>
        </div>
      </div>
    </div>
  );
};
